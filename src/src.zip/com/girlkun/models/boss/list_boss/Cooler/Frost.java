package com.girlkun.models.boss.list_boss.Cooler;

public class Frost {
}
