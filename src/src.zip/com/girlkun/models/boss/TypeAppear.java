package com.girlkun.models.boss;


public enum TypeAppear {

    DEFAULT_APPEAR,
    APPEAR_WITH_ANOTHER,
    ANOTHER_LEVEL,
    CALL_BY_ANOTHER
    
}

/**
 * Vui lòng không sao chép mã nguồn này dưới mọi hình thức. Hãy tôn trọng tác
 * giả của mã nguồn này. Xin cảm ơn! - Girlkun75
 */
