/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.girlkun.models.boss;

/**
 *
 * @author admin
 */
public enum BossStatus {
    REST,
    RESPAWN,
    JOIN_MAP,
    CHAT_S,
    ACTIVE,
    DIE,
    CHAT_E,
    LEAVE_MAP

}
