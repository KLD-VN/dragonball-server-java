package com.girlkun.models.boss.iboss;


public interface IBossOutfit {

    short getHead();

    short getBody();

    short getLeg();

    short getFlagBag();

    byte getAura();

    byte getEffFront();
}






















