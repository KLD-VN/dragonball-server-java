package com.girlkun.models.matches;


public enum TYPE_PVP {

    THACH_DAU,
    TRA_THU,
    DAI_HOI_VO_THUAT
    
}





















