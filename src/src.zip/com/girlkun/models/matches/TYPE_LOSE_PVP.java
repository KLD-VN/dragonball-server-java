package com.girlkun.models.matches;


public enum TYPE_LOSE_PVP {

    RUNS_AWAY,
    DEAD

}






















